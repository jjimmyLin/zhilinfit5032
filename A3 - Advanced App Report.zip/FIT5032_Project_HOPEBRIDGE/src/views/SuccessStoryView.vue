<!--This is the Success story page to display stories taht hekps unemployed users recover and motivated-->

<template>
    <div class="story">
        <div class="title text-center text-decoration-underline">
            <h1>Story of the week</h1>
        </div>
        <h2>A Story of Perseverance: John's Journey from Unemployment to Success</h2>
        <p>
            John, a 35-year-old marketing professional, found himself in a difficult situation when his company
            downsized and he was laid off. As the months passed, John faced rejection after rejection. His confidence
            waned, and doubt crept into his thoughts. Despite this, he refused to give up. He knew that the key to
            overcoming his unemployment lay in his determination and effort.
        </p>
        <p>
            John decided to make a plan. He began by assessing his skills and identifying gaps that could be holding him
            back. Recognizing the growing importance of digital marketing, he enrolled in an online course to learn
            about social media strategies and analytics. He also took on freelance work to keep his skills sharp and to
            network with professionals in the industry. Every day, he dedicated hours to learning and improving his
            skills, even when he felt discouraged.
        </p>
        <p>
            John knew that effort alone wasn't enough; he needed to be strategic. He revamped his resume to highlight
            his new skills and crafted tailored cover letters for each job application. Instead of focusing on what he
            lacked, he emphasized his adaptability, his willingness to learn, and his passion for marketing. He also
            began attending virtual networking events, connecting with industry professionals who offered valuable
            advice and job leads.
        </p>
        <p>
            After several months of relentless effort, John finally got a break. He was offered a position as a digital
            marketing coordinator at a mid-sized firm. Though the role was at a lower level than his previous job, John
            saw it as an opportunity to prove himself. Within a year, he was promoted, having demonstrated his value
            through innovative campaigns that increased the company's online presence.
        </p>
        <p>
            John's journey from unemployment to success was not easy, but it was a testament to the power of
            perseverance, continuous learning, and strategic action. His story is a reminder that even in the face of
            adversity, effort and determination can pave the way to new opportunities.
        </p>
    </div>
</template>

<script>
export default
    {
        name: 'story',
    };
</script>

<style scoped>
.title {
    text-align: center;
    color: #e633aa;
}
.story {
    max-width: 750px;
    margin: 0 auto;
    padding: 20px;
    line-height: 1.3;
    background-color: #ffffff;
    border-radius: 25px;
    box-shadow: 0 0px 20px rgba(0, 0, 0, 0.1);
    border: 1px solid #ffa8df;
}

h2 {
    text-align: center;
    color: #ed96d0;
}

p {
    color: #050404;
}
</style>