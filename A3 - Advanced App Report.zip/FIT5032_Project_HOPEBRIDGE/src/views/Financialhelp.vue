<script>
import FinhelptableView from './FinhelptableView.vue';
export default {
    components: {
        FinhelptableView
    }
}
</script>

<template>
    <div class="Table">
        <FinhelptableView />
    </div>
</template>