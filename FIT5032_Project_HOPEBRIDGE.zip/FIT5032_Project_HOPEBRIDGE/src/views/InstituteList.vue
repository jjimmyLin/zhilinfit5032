<script>
import InstitutiontableView
    from './InstitutiontableView.vue'; export default {
        components: {
            InstitutiontableView
        }
    }
</script>

<template>
    <div class="Table">
        <InstitutiontableView />
    </div>
</template>